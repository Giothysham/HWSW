# READ ME

This template folder contains everything to get you started. In the **firmware** folder you can find 3 subfolders. The final one (course_example_2) is built and run, so you have a working example, without having to crosscompile first.
